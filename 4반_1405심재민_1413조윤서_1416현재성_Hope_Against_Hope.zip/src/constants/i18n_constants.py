# constants related to translation and locale

I18N_DIRECTORY = 'i18n/'
DEVELOPMENT_LANG = 'ko_KR'
