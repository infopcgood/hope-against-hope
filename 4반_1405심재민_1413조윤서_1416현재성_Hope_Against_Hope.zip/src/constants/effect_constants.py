# constants about effects

SCREEN_SHAKE_AMOUNT = 3

FADE_SPEED = 3.2
